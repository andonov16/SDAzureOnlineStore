﻿namespace OnlineStore.Server.Model
{
    public enum ItemCategory
    {
        None = 0,
        Proteins = 1,
        PreworkoutSuplements = 2,
        Vitamins = 3
    }
}
